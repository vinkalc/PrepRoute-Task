import axios from 'axios'
import { useAuthStore } from '../store/authStore'
import toast from 'react-hot-toast'

const BASE_URL = import.meta.env.VITE_API_BASE_URL || 'https://admin-moderator-backend-staging.up.railway.app/api';

export const apiClient = axios.create({
  baseURL: BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
})

// Request Interceptor: Injects the authorization token
apiClient.interceptors.request.use(
  (config) => {
    const token = useAuthStore.getState().token
    if (token && config.headers) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

// Response Interceptor: Handles authorization expirations and error toasts
apiClient.interceptors.response.use(
  (response) => {
    return response
  },
  (error) => {
    const status = error.response?.status
    const message = error.response?.data?.message || error.message || 'An unexpected error occurred'

    if (status === 401) {
      // Automatic logout on token expiration
      toast.error('Session expired. Please log in again.')
      useAuthStore.getState().logout()
      // Redirect to login if not already there
      if (window.location.pathname !== '/login') {
        window.location.href = '/login'
      }
    } else if (status === 403) {
      toast.error('Forbidden: You do not have permissions to perform this action.')
    } else if (status === 404) {
      // Don't toast 404s globally always, but useful as general fallback
      console.warn('API Resource not found:', error.config?.url)
    } else if (status >= 500) {
      toast.error(`Server Error (${status}): Please try again later.`)
    } else {
      // Connection errors, network issues
      toast.error(message)
    }

    return Promise.reject(error)
  }
)
