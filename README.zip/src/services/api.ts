import type { ApiResponse, Subject, Topic, SubTopic, Test, Question, LoginData } from '../types'

// Local DB Storage Keys
const DB_KEYS = {
  SUBJECTS: 'preproute_db_subjects',
  TOPICS: 'preproute_db_topics',
  SUBTOPICS: 'preproute_db_subtopics',
  TESTS: 'preproute_db_tests',
  QUESTIONS: 'preproute_db_questions'
}

// Seed Data
const INITIAL_SUBJECTS: Subject[] = [
  { id: 'sub-math', name: 'Math' },
  { id: 'sub-physics', name: 'Physics' },
  { id: 'sub-chemistry', name: 'Chemistry' }
]

const INITIAL_TOPICS: Topic[] = [
  { id: 'top-algebra', name: 'Algebra', subject_id: 'sub-math' },
  { id: 'top-calculus', name: 'Calculus', subject_id: 'sub-math' },
  { id: 'top-mechanics', name: 'Mechanics', subject_id: 'sub-physics' },
  { id: 'top-thermo', name: 'Thermodynamics', subject_id: 'sub-physics' }
]

const INITIAL_SUBTOPICS: SubTopic[] = [
  { id: 'subtop-linear', name: 'Linear Equations', topic_id: 'top-algebra' },
  { id: 'subtop-quadratic', name: 'Quadratic Equations', topic_id: 'top-algebra' },
  { id: 'subtop-limits', name: 'Limits', topic_id: 'top-calculus' },
  { id: 'subtop-derivatives', name: 'Derivatives', topic_id: 'top-calculus' },
  { id: 'subtop-kinematics', name: 'Kinematics', topic_id: 'top-mechanics' },
  { id: 'subtop-newton', name: 'Newton\'s Laws', topic_id: 'top-mechanics' }
]

const INITIAL_TESTS: Test[] = [
  {
    id: 'test-1',
    name: 'Algebra Chapterwise Assessment',
    type: 'chapterwise',
    subject: 'sub-math',
    topics: ['top-algebra'],
    sub_topics: ['subtop-linear', 'subtop-quadratic'],
    correct_marks: 5,
    wrong_marks: -1,
    unattempt_marks: 0,
    total_time: 60,
    total_marks: 100,
    total_questions: 25,
    difficulty: 'medium',
    status: null, // Draft
    questions: [],
    created_at: new Date(Date.now() - 3600000).toISOString()
  },
  {
    id: 'test-2',
    name: 'Kinematics Practice Test',
    type: 'chapterwise',
    subject: 'sub-physics',
    topics: ['top-mechanics'],
    sub_topics: ['subtop-kinematics'],
    correct_marks: 4,
    wrong_marks: -1,
    unattempt_marks: 0,
    total_time: 45,
    total_marks: 80,
    total_questions: 20,
    difficulty: 'easy',
    status: 'live',
    questions: [],
    created_at: new Date(Date.now() - 86400000).toISOString()
  }
]

// Database Initializer
const initLocalStorageDB = () => {
  if (!localStorage.getItem(DB_KEYS.SUBJECTS)) {
    localStorage.setItem(DB_KEYS.SUBJECTS, JSON.stringify(INITIAL_SUBJECTS))
  }
  if (!localStorage.getItem(DB_KEYS.TOPICS)) {
    localStorage.setItem(DB_KEYS.TOPICS, JSON.stringify(INITIAL_TOPICS))
  }
  if (!localStorage.getItem(DB_KEYS.SUBTOPICS)) {
    localStorage.setItem(DB_KEYS.SUBTOPICS, JSON.stringify(INITIAL_SUBTOPICS))
  }
  if (!localStorage.getItem(DB_KEYS.TESTS)) {
    localStorage.setItem(DB_KEYS.TESTS, JSON.stringify(INITIAL_TESTS))
  }
  if (!localStorage.getItem(DB_KEYS.QUESTIONS)) {
    localStorage.setItem(DB_KEYS.QUESTIONS, JSON.stringify([]))
  }
}

// Run initializer immediately
initLocalStorageDB()

// DB Helper Methods
const db = {
  getSubjects: (): Subject[] => JSON.parse(localStorage.getItem(DB_KEYS.SUBJECTS) || '[]'),
  getTopics: (): Topic[] => JSON.parse(localStorage.getItem(DB_KEYS.TOPICS) || '[]'),
  getSubTopics: (): SubTopic[] => JSON.parse(localStorage.getItem(DB_KEYS.SUBTOPICS) || '[]'),
  getTests: (): Test[] => JSON.parse(localStorage.getItem(DB_KEYS.TESTS) || '[]'),
  saveTests: (tests: Test[]) => localStorage.setItem(DB_KEYS.TESTS, JSON.stringify(tests)),
  getQuestions: (): Question[] => JSON.parse(localStorage.getItem(DB_KEYS.QUESTIONS) || '[]'),
  saveQuestions: (questions: Question[]) => localStorage.setItem(DB_KEYS.QUESTIONS, JSON.stringify(questions))
}

// Authentication Service
export const authService = {
  login: async (userId: string, password: string): Promise<ApiResponse<LoginData>> => {
    return new Promise((resolve) => {
      setTimeout(() => {
        if (userId === 'vedant-admin' && password === 'vedant123') {
          resolve({
            success: true,
            message: 'Login successful',
            data: {
              token: 'mock-jwt-token-12345',
              user: {
                id: '1',
                username: 'vedant-admin',
                role: 'admin',
                phone: '7322881929',
                joiningDate: '2025-12-16',
                endDate: '2026-12-31',
                lastActive: new Date().toISOString(),
                payment: true,
              }
            }
          })
        } else {
          resolve({
            success: false,
            message: 'Invalid credentials. Please use vedant-admin / vedant123',
            data: null as any
          })
        }
      }, 300)
    })
  },
}

// Subjects Service
export const subjectService = {
  getAll: async (): Promise<ApiResponse<Subject[]>> => {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          success: true,
          message: 'Subjects fetched successfully',
          data: db.getSubjects()
        })
      }, 150)
    })
  },
}

// Topics & Sub-topics Service
export const topicService = {
  getAll: async (): Promise<ApiResponse<Topic[]>> => {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          success: true,
          message: 'Topics fetched successfully',
          data: db.getTopics()
        })
      }, 150)
    })
  },

  getBySubject: async (subjectId: string): Promise<ApiResponse<Topic[]>> => {
    return new Promise((resolve) => {
      setTimeout(() => {
        const filtered = db.getTopics().filter((t) => t.subject_id === subjectId)
        resolve({
          success: true,
          message: 'Topics fetched successfully',
          data: filtered
        })
      }, 150)
    })
  },
  
  getByTopic: async (topicId: string): Promise<ApiResponse<SubTopic[]>> => {
    return new Promise((resolve) => {
      setTimeout(() => {
        const filtered = db.getSubTopics().filter((s) => s.topic_id === topicId)
        resolve({
          success: true,
          message: 'Sub-topics fetched successfully',
          data: filtered
        })
      }, 150)
    })
  },

  getByMultiTopics: async (topicIds: string[]): Promise<ApiResponse<SubTopic[]>> => {
    return new Promise((resolve) => {
      setTimeout(() => {
        const filtered = db.getSubTopics().filter((s) => topicIds.includes(s.topic_id))
        resolve({
          success: true,
          message: 'Sub-topics fetched successfully',
          data: filtered
        })
      }, 150)
    })
  },
}

// Tests Service
export const testService = {
  getAll: async (): Promise<ApiResponse<Test[]>> => {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          success: true,
          message: 'Tests fetched successfully',
          data: db.getTests()
        })
      }, 200)
    })
  },

  getById: async (id: string): Promise<ApiResponse<Test>> => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const test = db.getTests().find((t) => t.id === id)
        if (test) {
          resolve({
            success: true,
            message: 'Test fetched successfully',
            data: test
          })
        } else {
          reject(new Error('Test not found'))
        }
      }, 150)
    })
  },

  create: async (testData: Omit<Test, 'id' | 'created_at' | 'status' | 'questions'>): Promise<ApiResponse<Test>> => {
    return new Promise((resolve) => {
      setTimeout(() => {
        const tests = db.getTests()
        const newTest: Test = {
          ...testData,
          id: `test-${Math.random().toString(36).substr(2, 9)}`,
          status: null, // Initial status is null / draft
          questions: [],
          created_at: new Date().toISOString()
        }
        tests.push(newTest)
        db.saveTests(tests)
        resolve({
          success: true,
          message: 'Test created successfully',
          data: newTest
        })
      }, 200)
    })
  },

  update: async (
    id: string, 
    testData: Partial<Omit<Test, 'id' | 'created_at'>>
  ): Promise<ApiResponse<Test>> => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const tests = db.getTests()
        const index = tests.findIndex((t) => t.id === id)
        if (index !== -1) {
          tests[index] = {
            ...tests[index],
            ...testData
          }
          db.saveTests(tests)
          resolve({
            success: true,
            message: 'Test updated successfully',
            data: tests[index]
          })
        } else {
          reject(new Error('Test not found'))
        }
      }, 200)
    })
  },

  publish: async (
    id: string, 
    scheduleDetails?: {
      publishMode: 'now' | 'schedule';
      scheduleDate?: string;
      scheduleTime?: string;
      liveUntilMode?: string;
      endDate?: string;
      endTime?: string;
    }
  ): Promise<ApiResponse<Test>> => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const tests = db.getTests()
        const index = tests.findIndex((t) => t.id === id)
        if (index !== -1) {
          if (scheduleDetails?.publishMode === 'schedule') {
            tests[index].status = 'scheduled'
            tests[index].schedule_date = scheduleDetails.scheduleDate
            tests[index].schedule_time = scheduleDetails.scheduleTime
          } else {
            tests[index].status = 'live'
          }
          tests[index].live_until = scheduleDetails?.liveUntilMode
          tests[index].end_date = scheduleDetails?.endDate
          tests[index].end_time = scheduleDetails?.endTime
          
          db.saveTests(tests)
          resolve({
            success: true,
            message: scheduleDetails?.publishMode === 'schedule' ? 'Test scheduled successfully' : 'Test published successfully',
            data: tests[index]
          })
        } else {
          reject(new Error('Test not found'))
        }
      }, 200)
    })
  },
}

// Questions Service
export const questionService = {
  bulkCreate: async (questions: Omit<Question, 'id'>[]): Promise<ApiResponse<Question[]>> => {
    return new Promise((resolve) => {
      setTimeout(() => {
        const dbQuestions = db.getQuestions()
        const newQuestions: Question[] = questions.map((q) => ({
          ...q,
          id: `q-${Math.random().toString(36).substr(2, 9)}`,
          created_at: new Date().toISOString()
        }))

        // Append to list of questions
        dbQuestions.push(...newQuestions)
        db.saveQuestions(dbQuestions)

        // Update the questions list reference on the test!
        if (newQuestions.length > 0) {
          const testId = newQuestions[0].test_id
          const tests = db.getTests()
          const index = tests.findIndex((t) => t.id === testId)
          if (index !== -1) {
            const currentQuestions = tests[index].questions || []
            const newIds = newQuestions.map((q) => q.id!)
            tests[index].questions = [...currentQuestions, ...newIds]
            db.saveTests(tests)
          }
        }

        resolve({
          success: true,
          message: 'Questions created successfully in bulk',
          data: newQuestions
        })
      }, 250)
    })
  },

  fetchBulk: async (questionIds: string[]): Promise<ApiResponse<Question[]>> => {
    return new Promise((resolve) => {
      setTimeout(() => {
        const matched = db.getQuestions().filter((q) => questionIds.includes(q.id!))
        resolve({
          success: true,
          message: 'Questions fetched successfully',
          data: matched
        })
      }, 200)
    })
  },
}
